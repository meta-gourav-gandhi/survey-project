export enum SurveyStatus {
    LIVE = 0, NOTLIVE = 1
}