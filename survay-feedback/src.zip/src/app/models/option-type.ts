export enum OptionType {
    TEXT,
    IMAGE,
    VIDEO
}
