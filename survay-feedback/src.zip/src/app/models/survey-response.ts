import { QuestionResponse } from './question-responses';
export class SurveyResponse {
    surveyId : number;
    questionResponses : QuestionResponse[];
}