import {Message} from './message';

export class ServerResponse {
    status : Message;
    body : any;
}