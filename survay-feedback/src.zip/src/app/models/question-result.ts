export class QuestionResult {
    id: number;
    option: string[];
    data: number[];
}