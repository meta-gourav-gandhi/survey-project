export class Label{
    name: string;
}