export class QuestionResponse{
    quesId : number;
    optionId : number;
}