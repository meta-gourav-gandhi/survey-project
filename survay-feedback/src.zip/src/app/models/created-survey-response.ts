export class CreatedSurveyResponse {
    id : number;
    name : string;
    url : string;
}