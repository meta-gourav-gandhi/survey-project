export class User{
    id : number;
    accessToken : string;
    role : number;
    viewer : boolean;
    name : string;
    email : string;
 }