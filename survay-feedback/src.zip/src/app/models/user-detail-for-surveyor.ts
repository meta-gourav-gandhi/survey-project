export class UserDetailForSurveyor{
    id : number;
    name : string;
    email : string;
    surveyViewer : boolean;
}