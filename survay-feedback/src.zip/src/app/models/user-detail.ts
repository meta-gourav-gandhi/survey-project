export class UserDetail{
    id : number;
    name : string;
    email : string;
    role : number;
}