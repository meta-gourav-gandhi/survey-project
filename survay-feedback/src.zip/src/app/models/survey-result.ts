import { QuestionResult } from './question-result';

export class SurveyResult {
    numOfResponders: number;
    questionResults: QuestionResult[];
}