export class Option {
    id: number;
    text: string;
}
