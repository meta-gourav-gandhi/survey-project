import { Injectable, OnInit } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class SharedServiceService implements OnInit {
  private subject;
  constructor() {
    this.subject = new BehaviorSubject(JSON.parse(localStorage.getItem('currentUser')) !== null); 
  }

  ngOnInit() {
   
  }
  

  saveUser(loggedIn: boolean) {
    this.subject.next(loggedIn);
  }

  getUser(): Observable<any> {
    return this.subject.asObservable();
  }

  clearUser() {
    this.subject.complete();
  }
}
